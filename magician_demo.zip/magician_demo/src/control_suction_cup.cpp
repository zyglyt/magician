#include <string>
#include <ros/ros.h>
#include <moveit/move_group_interface/move_group_interface.h>
#include <iostream>
#include "magician_hardware/SetEndEffectorSuctionCup.h"
 
int main(int argc, char **argv)
{
    ros::init(argc, argv, "control_suction_cup_demo");
    ros::AsyncSpinner spinner(1);
    spinner.start();
 
    ros::NodeHandle n;
 
ros::ServiceClient client;
	client = n.serviceClient<magician_hardware::SetEndEffectorSuctionCup>("/DobotServer/SetEndEffectorSuctionCup");
	//设置气泵吸取suck1
	magician_hardware::SetEndEffectorSuctionCup suck1;
	suck1.request.enableCtrl = 1;
	suck1.request.suck =1;
	suck1.request.isQueued = true;
	//设置气泵关闭suck2
	magician_hardware::SetEndEffectorSuctionCup suck2;
	suck2.request.enableCtrl = 0;
	suck2.request.suck =0;
	suck2.request.isQueued = true;



	//开启气泵吸气---关闭夹爪
	client.call(suck1);
 
 
	//关闭气泵
	client.call(suck2);

    ros::shutdown();

    return 0;
}