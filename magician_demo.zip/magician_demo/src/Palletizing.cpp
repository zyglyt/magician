#include <string>
#include <ros/ros.h>
#include <moveit/move_group_interface/move_group_interface.h>
#include <iostream>
#include "dobot/SetEndEffectorGripper.h"

// 1 张开 0闭合
dobot::SetEndEffectorGripper gripflag(int n)
{
    dobot::SetEndEffectorGripper srv;
    if (n == 1) // 张开
    {
        srv.request.enableCtrl = 1;
        srv.request.grip = 0;
        srv.request.isQueued = 1;
    }
    else if (n == 0) // 闭合
    {
        srv.request.enableCtrl = 1;
        srv.request.grip = 1;
        srv.request.isQueued = 1;
    }
    else
    {
        srv.request.enableCtrl = 0;
        srv.request.grip = 0;
        srv.request.isQueued = 0;
    }
    return srv;
}

void close(ros::ServiceClient& client)
{
    auto close = gripflag(2);
    client.call(close);

}

void gripper(ros::ServiceClient& client,dobot::SetEndEffectorGripper& srv){
 
    std::string info[]={"闭合","张开"};

 if (client.call(srv))
    {
        if (srv.response.result == 1)
        {
            ROS_INFO(std::string("夹爪"+ info[srv.request.grip]).c_str());
        }
        else
        {
            ROS_INFO(std::string("夹爪"+info[1-srv.request.grip]).c_str());
        }
    }
    else
    {
        ROS_ERROR("Failed to call SetEndEffectorGripper service");
        return;
    }

}

geometry_msgs::Pose points(float x,float y,float z){
    geometry_msgs::Pose target_pose;
    target_pose.orientation.x = 0.0;
    target_pose.orientation.y = 0.0;
    target_pose.orientation.z = 0.0;
    target_pose.orientation.w = 0.1;
 
    target_pose.position.x = x;
    target_pose.position.y = y;
    target_pose.position.z = z;

    return target_pose;
}


int main(int argc, char **argv)
{
    setlocale(LC_ALL, "");
    ros::init(argc, argv, "magician_palletizing");
    ros::AsyncSpinner spinner(1);
    spinner.start();
 
    ros::NodeHandle n;
 
    ros::ServiceClient client;
    // 设置夹爪开闭服务
    client = n.serviceClient<dobot::SetEndEffectorGripper>("/DobotServer/SetEndEffectorGripper");
    // 闭合
    auto srv = gripflag(0);
    // 张开
    auto srv1 = gripflag(1);

    moveit::planning_interface::MoveGroupInterface arm("magician_arm");
 
    //获取终端link的名称
    std::string end_effector_link = arm.getEndEffectorLink();
 
    //设置目标位置所使用的参考坐标系
    std::string reference_frame = "magician_origin";
    arm.setPoseReferenceFrame(reference_frame);
 
    //当运动规划失败后，允许重新规划
    arm.allowReplanning(true);
 
    //设置位置(单位：米)和姿态（单位：弧度）的允许误差
    arm.setGoalPositionTolerance(0.0002);
    arm.setGoalOrientationTolerance(0.001);
 
    //设置允许的最大速度和加速度
    arm.setMaxAccelerationScalingFactor(0.8);
    arm.setMaxVelocityScalingFactor(0.8);
 
    // 控制机械臂先回到初始化位置
    arm.setNamedTarget("home");
    arm.move();
    sleep(1);

    //张开
    gripper(client,srv1);

    // 设置机器人终端的目标位置
    // geometry_msgs::Pose target_pose;
    // target_pose.orientation.x = 0.0;
    // target_pose.orientation.y = 0.0;
    // target_pose.orientation.z = 0.0;
    // target_pose.orientation.w = 0.1;
 
    // target_pose.position.x = 0.13731;
    // target_pose.position.y = -0.12658;
    // target_pose.position.z = -0.01313;

     // 设置机器人终端的目标位置
    auto point0 = points(0.13731,-0.12658,0.01);

    // 设置机器臂当前的状态作为运动初始状态
    arm.setStartStateToCurrentState();
 
    arm.setPoseTarget(point0);
 
    // 进行运动规划，计算机器人移动到目标的运动轨迹，此时只是计算出轨迹，并不会控制机械臂运动
    moveit::planning_interface::MoveGroupInterface::Plan plan;
    moveit::planning_interface::MoveItErrorCode success = arm.plan(plan);
 
    ROS_INFO("Plan (pose goal) %s",success?"":"FAILED");   
 
    //让机械臂按照规划的轨迹开始运动。
    if(success){
      arm.execute(plan);
    sleep(1);
    }

    // 设置机器人终端的目标位置
    // target_pose.orientation.x = 0.0;
    // target_pose.orientation.y = 0.0;
    // target_pose.orientation.z = 0.0;
    // target_pose.orientation.w = 0.1;
 
    // target_pose.position.x = 0.13731;
    // target_pose.position.y = -0.12658;
    // target_pose.position.z = -0.03313;
    
    auto point1 = points(0.13731,-0.12658,-0.01313);

 
    // 设置机器臂当前的状态作为运动初始状态
    arm.setStartStateToCurrentState();
 
    arm.setPoseTarget(point1);
 
    // 进行运动规划，计算机器人移动到目标的运动轨迹，此时只是计算出轨迹，并不会控制机械臂运动
	success = arm.plan(plan);
 
    ROS_INFO("Plan (pose goal) %s",success?"":"FAILED");   
 
    //让机械臂按照规划的轨迹开始运动。
    if(success){
      arm.execute(plan);
    sleep(1);
    }

    // 等待一段时间
    ros::Duration(1.0).sleep();
    // 闭合
    gripper(client,srv);

    ros::Duration(1.0).sleep();
 
    // 控制机械臂先回到初始化位置
    arm.setNamedTarget("home");
    arm.move();
    sleep(1);
 
    // 设置机器人终端的目标位置
    // target_pose.orientation.x = 0.0;
    // target_pose.orientation.y = 0.0;
    // target_pose.orientation.z = 0.0;
    // target_pose.orientation.w = 0.1;
 
    // target_pose.position.x = 0.13731;
    // target_pose.position.y = 0.13265;
    // target_pose.position.z = -0.03313;

    auto point2 = points(0.13731,0.13265,-0.03813);

 
    // 设置机器臂当前的状态作为运动初始状态
    arm.setStartStateToCurrentState();
 
    arm.setPoseTarget(point2);
 
    // 进行运动规划，计算机器人移动到目标的运动轨迹，此时只是计算出轨迹，并不会控制机械臂运动
	success = arm.plan(plan);
 
    ROS_INFO("Plan (pose goal) %s",success?"":"FAILED");   
 
    //让机械臂按照规划的轨迹开始运动。
    if(success){
      arm.execute(plan);
    sleep(1);
    }

    ros::Duration(1.0).sleep();
    //张开
    gripper(client,srv1);

    ros::Duration(1.0).sleep();

    // 设置机器人终端的目标位置
    // target_pose.orientation.x = 0.0;
    // target_pose.orientation.y = 0.0;
    // target_pose.orientation.z = 0.0;
    // target_pose.orientation.w = 0.1;
 
    // target_pose.position.x = 0.13731;
    // target_pose.position.y = 0.13265;
    // target_pose.position.z = -0.01313;

    auto point3 = points(0.13731,0.13265,0);

 
    // 设置机器臂当前的状态作为运动初始状态
    arm.setStartStateToCurrentState();
 
    arm.setPoseTarget(point3);
 
    // 进行运动规划，计算机器人移动到目标的运动轨迹，此时只是计算出轨迹，并不会控制机械臂运动
	  success = arm.plan(plan);
 
    ROS_INFO("Plan (pose goal) %s",success?"":"FAILED");   
 
    //让机械臂按照规划的轨迹开始运动。
    if(success){
      arm.execute(plan);
    sleep(1);
    }
    
    //闭合
    gripper(client,srv);
    ros::Duration(1.0).sleep();
//////////////////////////////////////////////////////////////////////////////////////
    //控制机械臂先回到初始化位置
    arm.setNamedTarget("home");
    arm.move();
    sleep(1);
    //张开
    gripper(client,srv1);

    // 设置机器人终端的目标位置
    // target_pose.orientation.x = 0.0;
    // target_pose.orientation.y = 0.0;
    // target_pose.orientation.z = 0.0;
    // target_pose.orientation.w = 0.1;
 
    // target_pose.position.x = 0.13731;
    // target_pose.position.y = -0.15265;
    // target_pose.position.z = -0.01313;

    auto point4 = points(0.12731,-0.16265,-0.01313);
    

    arm.setStartStateToCurrentState();
 
    arm.setPoseTarget(point4);
 
    // 进行运动规划，计算机器人移动到目标的运动轨迹，此时只是计算出轨迹，并不会控制机械臂运动
	success = arm.plan(plan);
 
    ROS_INFO("Plan (pose goal) %s",success?"":"FAILED");   
 
    //让机械臂按照规划的轨迹开始运动。
    if(success){
      arm.execute(plan);
    sleep(1);
    }

    ros::Duration(1.0).sleep();

     // 设置机器人终端的目标位置
    // target_pose.orientation.x = 0.0;
    // target_pose.orientation.y = 0.0;
    // target_pose.orientation.z = 0.0;
    // target_pose.orientation.w = 0.1;
 
    // target_pose.position.x = 0.13731;
    // target_pose.position.y = -0.15265;
    // target_pose.position.z = -0.03313;

    auto point5 = points(0.12731,-0.16265,-0.04313);

    arm.setStartStateToCurrentState();
 
    arm.setPoseTarget(point5);
 
    // 进行运动规划，计算机器人移动到目标的运动轨迹，此时只是计算出轨迹，并不会控制机械臂运动
	success = arm.plan(plan);
 
    ROS_INFO("Plan (pose goal) %s",success?"":"FAILED");   
 
    //让机械臂按照规划的轨迹开始运动。
    if(success){
      arm.execute(plan);
    sleep(1);
    }

    ros::Duration(0.5).sleep();
    //闭合
    gripper(client,srv);

    ros::Duration(1.0).sleep();

    // 设置机器人终端的目标位置
    // target_pose.orientation.x = 0.0;
    // target_pose.orientation.y = 0.0;
    // target_pose.orientation.z = 0.0;
    // target_pose.orientation.w = 0.1;
 
    // target_pose.position.x = 0.13731;
    // target_pose.position.y = -0.15265;
    // target_pose.position.z = -0.01313;

    auto point6 = points(0.13731,-0.15265,-0.01313);


    arm.setStartStateToCurrentState();
 
    arm.setPoseTarget(point6);
 
    // 进行运动规划，计算机器人移动到目标的运动轨迹，此时只是计算出轨迹，并不会控制机械臂运动
	success = arm.plan(plan);
 
    ROS_INFO("Plan (pose goal) %s",success?"":"FAILED");   
 
    //让机械臂按照规划的轨迹开始运动。
    if(success){
      arm.execute(plan);
    sleep(1);
    }
    ros::Duration(1.0).sleep();

    // 设置机器人终端的目标位置
    // target_pose.orientation.x = 0.0;
    // target_pose.orientation.y = 0.0;
    // target_pose.orientation.z = 0.0;
    // target_pose.orientation.w = 0.1;
 
    // target_pose.position.x = 0.13731;
    // target_pose.position.y = 0.15265;
    // target_pose.position.z = -0.03313;

    auto point7 = points(0.11731,0.11265,-0.04013);


    arm.setStartStateToCurrentState();
 
    arm.setPoseTarget(point7);
 
    // 进行运动规划，计算机器人移动到目标的运动轨迹，此时只是计算出轨迹，并不会控制机械臂运动
	success = arm.plan(plan);
 
    ROS_INFO("Plan (pose goal) %s",success?"":"FAILED");   
 
    //让机械臂按照规划的轨迹开始运动。
    if(success){
      arm.execute(plan);
    sleep(1);
    }

    ros::Duration(0.5).sleep();
   //张开 
    gripper(client,srv1);

    ros::Duration(1.0).sleep();

    // 设置机器人终端的目标位置
    // target_pose.orientation.x = 0.0;
    // target_pose.orientation.y = 0.0;
    // target_pose.orientation.z = 0.0;
    // target_pose.orientation.w = 0.1;
 
    // target_pose.position.x = 0.13731;
    // target_pose.position.y = 0.15265;
    // target_pose.position.z = -0.01313;

    auto point8 = points(0.11731,0.11265,-0.01313);

    arm.setStartStateToCurrentState();
 
    arm.setPoseTarget(point8);
 
    // 进行运动规划，计算机器人移动到目标的运动轨迹，此时只是计算出轨迹，并不会控制机械臂运动
	success = arm.plan(plan);
 
    ROS_INFO("Plan (pose goal) %s",success?"":"FAILED");   
 
    //让机械臂按照规划的轨迹开始运动。
    if(success){
      arm.execute(plan);
    sleep(1);
    }

    // 控制机械臂先回到初始化位置
    arm.setNamedTarget("home");
    arm.move();
    sleep(1);

//////////////////////////////////////////////////////////////
    auto point9 = points(0.13731,-0.12658,-0.01313);

    arm.setStartStateToCurrentState();
 
    arm.setPoseTarget(point9);
 
    // 进行运动规划，计算机器人移动到目标的运动轨迹，此时只是计算出轨迹，并不会控制机械臂运动
	  success = arm.plan(plan);
 
    ROS_INFO("Plan (pose goal) %s",success?"":"FAILED");   
 
    //让机械臂按照规划的轨迹开始运动。
    if(success){
      arm.execute(plan);
    sleep(1);
    }

    ros::Duration(1.0).sleep();

    auto point10 = points(0.13731,-0.12658,-0.04313);

    arm.setStartStateToCurrentState();
 
    arm.setPoseTarget(point10);
 
    // 进行运动规划，计算机器人移动到目标的运动轨迹，此时只是计算出轨迹，并不会控制机械臂运动
	success = arm.plan(plan);
 
    ROS_INFO("Plan (pose goal) %s",success?"":"FAILED");   
 
    //让机械臂按照规划的轨迹开始运动。
    if(success){
      arm.execute(plan);
    sleep(1);
    }

    ros::Duration(1.0).sleep();
    //闭合
    gripper(client,srv);

    ros::Duration(1.0).sleep();

    auto point11 = points(0.13731,0.13265,0.01313);

    arm.setStartStateToCurrentState();
 
    arm.setPoseTarget(point11);
 
    // 进行运动规划，计算机器人移动到目标的运动轨迹，此时只是计算出轨迹，并不会控制机械臂运动
	success = arm.plan(plan);
 
    ROS_INFO("Plan (pose goal) %s",success?"":"FAILED");   
 
    //让机械臂按照规划的轨迹开始运动。
    if(success){
      arm.execute(plan);
    sleep(1);
    }

    ros::Duration(1.0).sleep();

    auto point12 = points(0.13731,0.13265,-0.01813);


    arm.setStartStateToCurrentState();
 
    arm.setPoseTarget(point12);
 
    // 进行运动规划，计算机器人移动到目标的运动轨迹，此时只是计算出轨迹，并不会控制机械臂运动
	success = arm.plan(plan);
 
    ROS_INFO("Plan (pose goal) %s",success?"":"FAILED");   
 
    //让机械臂按照规划的轨迹开始运动。
    if(success){
      arm.execute(plan);
    sleep(1);
    }

    ros::Duration(1.0).sleep();
    //张开
    gripper(client,srv1);

    ros::Duration(1.0).sleep();

    auto point13 = points(0.13731,0.13265,0.00313);


    arm.setStartStateToCurrentState();
 
    arm.setPoseTarget(point13);
 
    // 进行运动规划，计算机器人移动到目标的运动轨迹，此时只是计算出轨迹，并不会控制机械臂运动
	success = arm.plan(plan);
 
    ROS_INFO("Plan (pose goal) %s",success?"":"FAILED");   
 
    //让机械臂按照规划的轨迹开始运动。
    if(success){
      arm.execute(plan);
    sleep(1);
    }

    ros::Duration(1.0).sleep();

    // 控制机械臂先回到初始化位置
    arm.setNamedTarget("home");
    arm.move();
    sleep(1);

    ros::Duration(1.0).sleep();
////////////////////////////////////////////////////////////////////////////////////////////////////



    //关闭控制器
    close(client);
    ros::shutdown(); 
 
    return 0;
}